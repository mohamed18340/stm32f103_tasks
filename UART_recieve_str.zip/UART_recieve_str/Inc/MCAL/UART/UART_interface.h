#ifndef		UART_INTERFACE_H
#define		UART_INTERFACE_H

#include "../Inc/MCAL/UART/UART_private.h"
typedef enum
{
	UART_1,UART_2,UART_3,UART_4,UART_5
}UART_num;
typedef enum
{
	UART_disable,UART_enable
}UART_MODE;
typedef enum
{
	eight_bits,nine_bits
}word_length;
typedef enum
{
	ParityDisable,ParityEnable
}ParityControl;
typedef enum
{
	EvenParity,OddParity
}ParitySelection;
typedef enum
{
	Interrupt_disable,Interrupt_enable
}Interrupt_mode;
typedef enum
{
	transmitter_disable,transmitter_enable
}transmitter_mode;
typedef enum
{
	reciever_disable,reciever_enable
}reciever_mode;
typedef struct
{
	UART_MODE UE;
	transmitter_mode TE;
	reciever_mode RE;
	Interrupt_mode PE;
	Interrupt_mode TXEIE;
	Interrupt_mode TCIE;
	Interrupt_mode RXNE;
	word_length M;
	ParityControl PCE;
	ParitySelection PS;
}uart_config;
void	MUART_voidInit(UART_t* UARTn,uart_config* UART_CR,u32 BaudRate);

void	MUART_voidTransmitChar(UART_t* UARTn,u8 Data,uart_config* UART_CR);

void	MUART_voidTransmitStr(UART_t* UARTn,u8 arr[],uart_config* UART_CR);

u8	MUART_u8ReceiveChar(UART_t* UARTn,uart_config* UART_CR);

u8 * MUART_u8ReceiveStr(UART_t * UARTn,uart_config *UART_CR);

#endif
