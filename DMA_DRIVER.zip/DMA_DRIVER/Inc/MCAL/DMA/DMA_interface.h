#ifndef DMA_INTERFACE_H
#define DMA_INTERFACE_H
#include "../Inc/MCAL/DMA/DMA_private.h"
///
////
typedef enum
{
	mem2mem_enable,mem2mem_disable
}mem2mem_mode;
typedef enum
{
	DMA_1,DMA_2
}DMA_NUM;
typedef enum
{
	CH1,CH2,CH3,CH4,CH5,CH6,CH7
}CHANNEL_NUM;
typedef enum
{
	low,medium,high,very_high
}priority;
typedef enum
{
	byte,half_word,word
}size;
typedef enum
{
	FromPripheral,FromMemory
}read_from;
typedef enum
{
	interrupt_enable,interrupt_disable
}Interrupt_state;
typedef enum
{
	MINC_enable,MINC_disable
}MINC_MODE;
typedef enum
{
	PINC_enable,PINC_disable
}PINC_MODE;
typedef enum
{
	channel_enable,channel_disable
}channel_mode;
typedef enum
{
	circ_enable,circ_disable
}CIRC_mode;
typedef enum
{
	TransferComplete,HalfTransfer,TransferError
}InterruptSource_t;
typedef struct
{
	channel_mode chMode;
	Interrupt_state TC;
	Interrupt_state HT;
	Interrupt_state TE;
	read_from DIR;
	CIRC_mode CIRC;
	PINC_MODE PINC;
	MINC_MODE MINC;
	size PSIZE;
	size MSIZE;
	priority PL;
	mem2mem_mode mem2mem;
}DMA_channel_config;
void DMA_init(DMA_NUM);
void DMA_CH_init(DMA_channel_config * DMA_CCR,CHANNEL_NUM ch_num,DMA_t *DMAnum);
void DMA_Transfer(DMA_t *DMAnum,CHANNEL_NUM ch_num,DMA_channel_config *DMA_CCR,u32* SourceAddress,u32* DestAddress,u32 NumberOfData);
void DMA_SetCallBack(DMA_t *DMAnum,CHANNEL_NUM ch_num,InterruptSource_t InterruptSource,void (*localFptr)(void));

#endif
