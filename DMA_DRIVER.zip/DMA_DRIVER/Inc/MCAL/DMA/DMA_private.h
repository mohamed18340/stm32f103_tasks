#ifndef DMA_PRIVATE_H
#define DMA_PRIVATE_H
#include "../Inc/LIB/STD_TYPES.h"
typedef struct
{
	volatile u32 CCR;
	volatile u32 CNDTR;
	volatile u32 CPAR;
	volatile u32 CMAR;
}DMA_CHANNEL;
typedef struct
{
	volatile u32 ISR;
	volatile u32 IFCR;
	DMA_CHANNEL channel[7];
}DMA_t;

#define DMA1_Address (0x40020000)
#define DMA2_Address (0x40020400)


#define DMA1 ((DMA_t *) DMA1_Address)
#define DMA2 ((DMA_t *) DMA2_Address)

#endif
