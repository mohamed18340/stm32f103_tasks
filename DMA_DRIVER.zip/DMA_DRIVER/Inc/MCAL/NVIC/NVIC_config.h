#ifndef			NVIC_CONFIG_H
#define			NVIC_CONFIG_H


#define MNVIC_GRP_SUB		MNVIC_4_GROUP_4_SUB


#endif



