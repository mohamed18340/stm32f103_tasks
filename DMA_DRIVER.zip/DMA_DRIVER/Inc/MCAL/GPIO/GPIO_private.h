#ifndef		GPIO_PRIVATE_H
#define		GPIO_PRIVATE_H

#define GPIOA ((volatile GPIOA_t *)0x40010800)

typedef struct
{
	volatile u32 GPIOA_CRL;
	volatile u32 GPIOA_CRH;
	volatile u32 GPIOA_IDR;
	volatile u32 GPIOA_ODR;
	volatile u32 GPIOA_BSRR;
	volatile u32 GPIOA_BRR;	
	volatile u32 GPIOA_LCKR;
}GPIOA_t;//registers of port A in one struct

#define GPIOB ((volatile GPIOB_t *)0x40010C00)

typedef struct
{
	volatile u32 GPIOB_CRL;
	volatile u32 GPIOB_CRH;
	volatile u32 GPIOB_IDR;
	volatile u32 GPIOB_ODR;
	volatile u32 GPIOB_BSRR;
	volatile u32 GPIOB_BRR;
	volatile u32 GPIOB_LCKR;
}GPIOB_t;//registers of port B in one struct

#define GPIOC ((volatile GPIOC_t *)0x40011000)

typedef struct
{
	volatile u32 GPIOC_CRL;
	volatile u32 GPIOC_CRH;
	volatile u32 GPIOC_IDR;
	volatile u32 GPIOC_ODR;
	volatile u32 GPIOC_BSRR;
	volatile u32 GPIOC_BRR;
	volatile u32 GPIOC_LCKR;
}GPIOC_t;//registers of port C in one struct




#endif
