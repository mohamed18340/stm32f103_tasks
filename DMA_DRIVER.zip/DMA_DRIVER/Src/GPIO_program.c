#include "../Inc/LIB/STD_TYPES.h"
#include "../Inc/LIB/BIT_MATH.h"


#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/GPIO/GPIO_private.h"
#include "../Inc/MCAL/GPIO/GPIO_config.h"


void	MGPIO_voidSetPinDirection	(u8 Copy_u8PortID ,u8 Copy_u8PinID ,u8 Copy_u8Direction )
{
		/*		Range Check			*/
	if(Copy_u8PortID<3 && Copy_u8PinID<16)
	{
		switch(Copy_u8PortID)
		{
			case	GPIO_U8_PORTA	:	
			/*	Check if Low				*/
			if(Copy_u8PinID <8)
			{
				//	#define		CLR(REG,BIT)		REG &=~(1<<BIT)
				/*	CLR The 4 bits Of Direction					*/
				GPIOA->GPIOA_CRL	&=~(  (0b1111)<< (Copy_u8PinID * 4)   );
				GPIOA->GPIOA_CRL	|=(  (Copy_u8Direction)	<< (Copy_u8PinID * 4));
			
			}else if(Copy_u8PinID <16)
			{
				Copy_u8PinID -= 8;
				/*	CLR The 4 bits Of Direction					*/
				GPIOA->GPIOA_CRH	&=~((0b1111)			<< (Copy_u8PinID * 4));
				GPIOA->GPIOA_CRH	|=((Copy_u8Direction)	<< (Copy_u8PinID * 4));
			}else{	/*	Return Error */	}		break;
			
			case	GPIO_U8_PORTB	:	
			/*	Check if Low				*/
			if(Copy_u8PinID <8)
			{
				//	#define		CLR(REG,BIT)		REG &=~(1<<BIT)
				/*	CLR The 4 bits Of Direction					*/
				GPIOB->GPIOB_CRL	&=~((0b1111)			<< (Copy_u8PinID * 4));
				GPIOB->GPIOB_CRL	|=((Copy_u8Direction)	<< (Copy_u8PinID * 4));
			
			}else if(Copy_u8PinID <16)
			{
				Copy_u8PinID -= 8;
				/*	CLR The 4 bits Of Direction					*/
				GPIOB->GPIOB_CRH	&=~((0b1111)			<< (Copy_u8PinID * 4));
				GPIOB->GPIOB_CRH	|=((Copy_u8Direction)	<< (Copy_u8PinID * 4));
			}else{	/*	Return Error */	}		break;
			
			case	GPIO_U8_PORTC	:	
			/*	Check if Low				*/
			if(Copy_u8PinID <8)
			{
				//	#define		CLR(REG,BIT)		REG &=~(1<<BIT)
				/*	CLR The 4 bits Of Direction					*/
				GPIOC->GPIOC_CRL	&=~((0b1111)			<< (Copy_u8PinID * 4));
				GPIOC->GPIOC_CRL	|=((Copy_u8Direction)	<< (Copy_u8PinID * 4));
			
			}else if(Copy_u8PinID <16)
			{
				Copy_u8PinID -= 8;
				/*	CLR The 4 bits Of Direction					*/
				GPIOC->GPIOC_CRH	&=~((0b1111)			<< (Copy_u8PinID * 4));
				GPIOC->GPIOC_CRH	|=((Copy_u8Direction)	<< (Copy_u8PinID * 4));
			}else{	/*	Return Error */	}		break;
		}
		
	}else{	/*	Return Error		*/	}	
}

//DIO_voidSetPinValue		(GPIO_U8_PORTA ,GPIO_U8_PIN0 ,GPIO_U8_HIGH	);
void	MGPIO_voidSetPinValue		(u8 Copy_u8PortID ,u8 Copy_u8PinID ,u8 Copy_u8Value		)
{
	/*		Range Check			*/
	if(Copy_u8PortID<3 && Copy_u8PinID<16)
	{
		if(Copy_u8Value == GPIO_U8_HIGH)
		{
			switch(Copy_u8PortID)
			{
				case	GPIO_U8_PORTA :	SET_BIT(GPIOA->GPIOA_ODR,Copy_u8PinID);	break;
				case	GPIO_U8_PORTB :	SET_BIT(GPIOB->GPIOB_ODR,Copy_u8PinID);	break;
				case	GPIO_U8_PORTC :	SET_BIT(GPIOC->GPIOC_ODR,Copy_u8PinID);	break;
			}
			
		}else if (Copy_u8Value == GPIO_U8_LOW)
		{
			switch(Copy_u8PortID)
			{
				case	GPIO_U8_PORTA :	CLR_BIT(GPIOA->GPIOA_ODR,Copy_u8PinID);	break;
				case	GPIO_U8_PORTB :	CLR_BIT(GPIOB->GPIOB_ODR,Copy_u8PinID);	break;
				case	GPIO_U8_PORTC :	CLR_BIT(GPIOC->GPIOC_ODR,Copy_u8PinID);	break;
			}	
		}else{	/*	Return Error	*/}
		
	}else{	/*	Return Error		*/	}
}
u8		MGPIO_u8GetPinValue		(u8 Copy_u8PortID ,u8 Copy_u8PinID )
{
	u8	Local_u8Value	= 0x55 ;
	/*		Range Check			*/
	if(Copy_u8PortID<3 && Copy_u8PinID<16)
	{
		switch(Copy_u8PortID)
		{
			case	GPIO_U8_PORTA :	Local_u8Value = GET_BIT(GPIOA->GPIOA_IDR,Copy_u8PinID);	break;
			case	GPIO_U8_PORTB :	Local_u8Value = GET_BIT(GPIOB->GPIOB_IDR,Copy_u8PinID);	break;
			case	GPIO_U8_PORTC :	Local_u8Value = GET_BIT(GPIOC->GPIOC_IDR,Copy_u8PinID);	break;
		}		
	}else{	/*	Return Error		*/	}	
	return Local_u8Value ;
}

void MGPIO_voidDelay(u32 Copy_u32Counter)
{
	for(u32 i = 0; i <= Copy_u32Counter; i++)
	{
		asm("NOP");
	}
}
void MGPIO_set_port_direction(u8 Copy_u8PortID,u8 Copy_u8Direction)
{
	MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN0, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN1, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN2, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN3, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN4, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN5, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN6, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN7, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN8, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN9, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN10, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN11, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN12, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN13, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN14, Copy_u8Direction);
			MGPIO_voidSetPinDirection(Copy_u8PortID, GPIO_U8_PIN15, Copy_u8Direction);

}
void MGPIO_set_port_value(u8 Copy_u8PortID,u8* port_data)
{
	/*MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN0, port_data[0]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN1, port_data[1]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN2, port_data[2]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN3, port_data[3]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN4, port_data[4]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN5, port_data[5]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN6, port_data[6]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN7, port_data[7]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN8, port_data[8]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN9, port_data[9]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN10, port_data[10]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN11, port_data[11]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN12, port_data[12]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN13, port_data[13]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN14, port_data[14]);
	MGPIO_voidSetPinValue(Copy_u8PortID, GPIO_U8_PIN15, port_data[15]);*/
	GPIOA->GPIOA_ODR &=0x00000000;
	GPIOA->GPIOA_ODR |=(u32)(port_data);

}


