#include "../Inc/MCAL/DMA/DMA_interface.h"
#include "../Inc/MCAL/DMA/DMA_private.h"
#include "../Inc/MCAL/RCC/RCC_interface.h"
#include "../Inc/LIB/BIT_MATH.h"
#include "../Inc/LIB/STD_TYPES.h"
#define NULLPTR ((void*)0)

static void (*DMA1_Fptr[7][3])(void)={NULLPTR};
static void (*DMA2_Fptr[5][3])(void)={NULLPTR};

void DMA_init(DMA_NUM DMAx)
{
	if(DMAx==DMA_1)
	{
		MRCC_voidPerClock_State(AHB, DMA1_PERIPHERAL, PClock_enable);
	}
	if(DMAx==DMA_2)
	{
		MRCC_voidPerClock_State(AHB, DMA2_PERIPHERAL, PClock_enable);
	}
}
void DMA_CH_init(DMA_channel_config * DMA_CCR,CHANNEL_NUM ch_num,DMA_t *DMAnum)
{
	//clear CCR register
	DMAnum->channel[ch_num].CCR =0X00000000;
	//set values of CCR
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->mem2mem)<<14;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->PL)<<12;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->MSIZE)<<10;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->PSIZE)<<8;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->MINC)<<7;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->PINC)<<6;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->CIRC)<<5;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->DIR)<<4;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->TE)<<3;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->HT)<<2;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->TC)<<1;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->chMode)<<0;

}
void DMA_Transfer(DMA_t *DMAnum,CHANNEL_NUM ch_num,DMA_channel_config *DMA_CCR,u32* SourceAddress,u32* DestAddress,u32 NumberOfData)
{
	DMAnum->channel[ch_num].CMAR=*DestAddress;
	DMAnum->channel[ch_num].CPAR=*SourceAddress;
	DMAnum->channel[ch_num].CNDTR=NumberOfData;
	DMA_CCR->chMode=channel_enable;
	DMAnum->channel[ch_num].CCR |=(DMA_CCR->chMode)<<0;
}
void DMA_SetCallBack(DMA_t *DMAnum,CHANNEL_NUM ch_num,InterruptSource_t InterruptSource,void (*localFptr)(void))
{
	if(DMAnum==DMA1)
	{
		DMA1_Fptr[ch_num][InterruptSource]=localFptr;
	}
	else
	{
		DMA2_Fptr[ch_num][InterruptSource]=localFptr;
	}
}
void DMA1_CH1_IRQhandler()
{
	//transfer complete
	if(GET_BIT(DMA1->ISR,1)==1)
		{
			if( DMA1_Fptr[0][0]!=NULLPTR)
				{DMA1_Fptr[0][0];}
			SET_BIT(DMA1->IFCR,1);
		}
	//half transfer
	else if(GET_BIT(DMA1->ISR,2)==1)
			{
				if( DMA1_Fptr[0][1]!=NULLPTR)
					{DMA1_Fptr[0][1];}
				SET_BIT(DMA1->IFCR,2);
			}
	//transfer error
	else if(GET_BIT(DMA1->ISR,3)==1)
			{
				if( DMA1_Fptr[0][2]!=NULLPTR)
					{DMA1_Fptr[0][2];}
				SET_BIT(DMA1->IFCR,3);
			}


}

