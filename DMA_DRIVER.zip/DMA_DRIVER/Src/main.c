#include "../Inc/LIB/BIT_MATH.h"
#include "../Inc/LIB/STD_TYPES.h"
#include "../Inc/MCAL/RCC/RCC_interface.h"
#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/NVIC/NVIC_interface.h"
#include "../Inc/MCAL/DMA/DMA_interface.h"
#include "../Inc/MCAL/DMA/DMA_private.h"
u32 arr1[100];
u32 arr2[100];
//main function
int main(void)
{
	DMA_init(DMA_1);

	DMA_channel_config *CCR = 0x00000000;
	//configuration of the control register
	CCR->mem2mem=mem2mem_enable;
	CCR->TE=interrupt_enable;
	CCR->TC=interrupt_enable;
	CCR->HT=interrupt_enable;
	CCR->PSIZE=word;
	CCR->PL=very_high;
	CCR->PINC=PINC_enable;
	CCR->MSIZE=word;
	CCR->MINC=MINC_enable;
	CCR->DIR=FromMemory;
	CCR->CIRC=circ_disable;

	DMA_CH_init(CCR, CH1, DMA1);

	MNVIC_voidEnableInterrupt(11);

	DMA_Transfer(DMA1, CH1, CCR, arr1, arr2, 100);

	for(int i=0;i<100;i++)
	{
		arr2[i]=arr1[i];
	}
	return 0;
}
