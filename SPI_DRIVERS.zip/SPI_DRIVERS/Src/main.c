#include "../Inc/MCAL/SPI/SPI_interface.h"
#include "../Inc/MCAL/SPI/SPI_private.h"
#include "../Inc/LIB/BIT_MATH.h"
#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/RCC/RCC_interface.h"

int main(void)
{
    MRCC_voidInit();
	MRCC_voidPerClock_State(APB2, AFIO_PERIPHERAL, PClock_enable);
	MRCC_voidPerClock_State(APB2, IOPA_PERIPHERAL, PClock_enable);
	MRCC_voidPerClock_State(APB2, SPI1_PERIPHERAL, PClock_enable);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN7, GPIO_U8_OUTPUT_AF_PP_10MHZ);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN6, GPIO_U8_INPUT_FLOATING);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN5, GPIO_U8_OUTPUT_AF_PP_10MHZ);
MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_OUTPUT_PP_10MHZ);
	MSPI_voidInit(SPI1);
	SPIcontrol * CR;
	CR->CPHAS= first_transition;
	CR->CPOL=LOW_IDLE;
	CR->MSTR=master;
	CR->BR=CLK_2;
	CR->SPE=SPI_ENABLE;
	CR->SB=MSB_first;
	CR->SSM=SSM_ENABLE;
	CR->RXONLY=FullDuplex;
	CR->DFF=byte;
	CR->BIDIOE=bidirection_transmit;
	CR->BIDIMODE=two_line_uni;
	CR->SSOE=SSOE_enable;

	char x;
	char y='A';
	MSPI_voidSendReceiveSynch(SPI1,CR,y, &x);
	if(x=='5')
	  {
	    MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_HIGH);
	  }
	else if(x=='A')
	  {
	    MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_LOW);

	  }


	for(;;);
}
