#include "../Inc/MCAL/SPI/SPI_interface.h"
#include "../Inc/MCAL/SPI/SPI_private.h"
#include "../Inc/LIB/BIT_MATH.h"
#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/RCC/RCC_interface.h"
//void (*SPI1callBack)(u8 *) = NULL;

void	MSPI_voidInit(SPI_t* SPIn)
{
  if(SPIn==SPI1)
    {
      MRCC_voidPerClock_State(APB2, SPI1_PERIPHERAL, PClock_enable);
    }
  if(SPIn==SPI2)
     {
        MRCC_voidPerClock_State(APB1, SPI2_PERIPHERAL, PClock_enable);
     }
  if(SPIn==SPI2)
     {
          MRCC_voidPerClock_State(APB1, SPI3_PERIPHERAL, PClock_enable);
     }
	SPIn->SPI_CR[0] = 0x0347;

}
void	MSPI_voidSendReceiveSynch(SPI_t* SPIn,SPIcontrol* SPI_CR,u8 Copy_u8DataTx , u8 * Copy_u8DataRx)
{
    SPIn->SPI_CR[0] &=0X00000000;
    SPIn->SPI_CR[1] &=0X00000000;
    SPIn->SPI_CR[0] |= ((SPI_CR->CPHAS)<<0);
    SPIn->SPI_CR[0] |= ((SPI_CR->CPOL)<1);
    SPIn->SPI_CR[0] |= ((SPI_CR->MSTR)<<2);
    SPIn->SPI_CR[0] |= ((SPI_CR->BR)<<3);
    SPIn->SPI_CR[0] |= ((SPI_CR->SPE)<<6);
    SPIn->SPI_CR[0] |= ((SPI_CR->SB)<<7);
    SPIn->SPI_CR[0] |= ((SPI_CR->SSM)<<9);
    SPIn->SPI_CR[0] |= ((SPI_CR->RXONLY)<<10);
    SPIn->SPI_CR[0] |= ((SPI_CR->DFF)<<11);
    SPIn->SPI_CR[0] |= ((SPI_CR->BIDIOE)<<14);
    SPIn->SPI_CR[0] |= ((SPI_CR->BIDIMODE)<<15);
    SPIn->SPI_CR[1] |= ((SPI_CR->SSOE)<<2);
    SPIn->SPI_CR[1] |= ((SPI_CR->ERRIE)<<5);
    SPIn->SPI_CR[1] |= ((SPI_CR->RXNEIE)<<6);
    SPIn->SPI_CR[1] |= ((SPI_CR->TXEIE)<<7);

	u8 Local_u8TimeOut = 0;

	//	Clear for Slave Selection Pin
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN0, GPIO_U8_OUTPUT_PP_10MHZ);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN0, GPIO_U8_LOW);
	/*	Send Data  */
	SPIn->SPI_DR =	Copy_u8DataTx;

	/*	wait Busy flag to finish 			*/
	while((GET_BIT(SPIn->SPI_SR, 7)==1)||(Local_u8TimeOut != 20000))
	{
		Local_u8TimeOut++;
	}

	/*	Return Data 						*/
	*Copy_u8DataRx = SPIn->SPI_DR;

	/*	Set for Slave Selection Pin 		*/
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN0, GPIO_U8_HIGH);
}
void	MSPI_voidSendReceiveAsynch(u8 Copy_u8DataTx , void (*CallBack)(u8 *))
{

}
