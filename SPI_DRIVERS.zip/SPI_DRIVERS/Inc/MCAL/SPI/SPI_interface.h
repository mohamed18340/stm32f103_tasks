#ifndef SPI_INTERFACE_H
#define SPI_INTERFACE_H
#include "SPI_private.h"
#include "../Inc/LIB/STD_TYPES.h"
typedef struct
{
    clock_phase CPHAS;
    clock_polarity CPOL;
    master_selection MSTR;
    baud_rate_ctrl BR;
    SPI_CONTROL SPE;
    SB_frame_format SB;
    software_slave_management SSM;
    receive_only RXONLY;
    DataFrameFormat DFF;
    direction_mode BIDIMODE;
    bidirection_mode BIDIOE;
    slave_select SSOE;
    interrupt_state TXEIE;
    interrupt_state RXNEIE;
    interrupt_state ERRIE;
}SPIcontrol;

void	MSPI_voidInit(SPI_t* SPIn);
void	MSPI_voidSendReceiveSynch(SPI_t* SPIn,SPIcontrol* SPI_CR,u8 Copy_u8DataTx , u8 * Copy_u8DataRx);
void	MSPI_voidSendReceiveAsynch(u8 Copy_u8DataTx , void (*CallBack)(u8 *));


#endif
