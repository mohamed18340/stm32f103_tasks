#ifndef SPI_PRIVATE_H_
#define SPI_PRIVATE_H_
#include "../Inc/LIB/STD_TYPES.h"
#define SPI1 ((volatile SPI_t *)0x40013000)
#define SPI2 ((volatile SPI_t *)0x40003800)
#define SPI3 ((volatile SPI_t *)0x40003C00)
typedef struct
{
	u32 SPI_CR[2];
	u32 SPI_SR;
	u32 SPI_DR;
	u32 SPI_CRCPR;
	u32 SPI_RXCRCR;
	u32 SPI_TXCRCR;
	u32 SPI_I2SCFGR;
	u32 SPI_I2SPR;
}SPI_t;

///////CR1/////////

typedef enum
{
	first_transition,second_transition
}clock_phase;
typedef enum
{
	LOW_IDLE,HIGH_IDLE
}clock_polarity;
typedef enum
{
	slave,master
}master_selection;
typedef enum{
	CLK_2,CLK_4,CLK_8,CLK_16,CLK_32,CLK_64,CLK_128,CLK_256
}baud_rate_ctrl;
typedef enum
{
	SPI_DISABLE,SPI_ENABLE
}SPI_CONTROL;
typedef enum
{
	MSB_first,LSB_first
}SB_frame_format;
typedef enum
{
	SSM_DISABLE,SSM_ENABLE
}software_slave_management;
typedef enum
{
	FullDuplex,ReceiveOnly
}receive_only;
typedef enum
{
	byte,HalfWord
}DataFrameFormat;
typedef enum{
	two_line_uni,
	one_line_bi
}direction_mode;
typedef enum
{
	bidirection_receive,bidirection_transmit
}bidirection_mode;

///////////////CR2////////////

typedef enum
{
	SSOE_disable,SSOE_enable
}slave_select;
typedef enum
{
	interrupt_disable,interrupt_enable
}interrupt_state;
#endif
