#include "../Inc/LIB/BIT_MATH.h"
#include "../Inc/LIB/STD_TYPES.h"
#include "../Inc/MCAL/UART/UART_interface.h"
#include "../Inc/MCAL/UART/UART_private.h"
#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/RCC/RCC_interface.h"
#include <stdint.h>

void delay(void)
{
	int x=0;
	for(x=0;x<10000;x++);
}
#include <stddef.h>

int main(void)
{
	/*	HSI RCC init				*/
	MRCC_voidInit();
	/*	RCC UART 1	(APB2,14)		*/
	MRCC_voidPerClock_State(APB2, USART1_PERIPHERAL, PClock_enable);
	MRCC_voidPerClock_State(APB2, IOPA_PERIPHERAL, PClock_enable);
	/*	Tx ==> A9 output push pull Alternate function */

	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN9, GPIO_U8_OUTPUT_AF_PP_10MHZ);
	/*	Rx ==> A10 Input floating 	*/
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN10, GPIO_U8_INPUT_FLOATING);
	uart_config *CR ;
	CR=NULL;
		CR->M=eight_bits;
		CR->PCE=ParityDisable;
		CR->PE=Interrupt_disable;
		CR->PS=EvenParity;
		CR->RXNE=Interrupt_disable;
		CR->TCIE=Interrupt_enable;
		CR->TXEIE=Interrupt_disable;
		CR->UE=UART_enable;
	/*	UART init					*/
	MUART_voidInit(UART1,CR,0X347);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_OUTPUT_PP_10MHZ);

	u8 x = 0;
	while(1)
	{
		MUART_voidTransmitStr(UART1,"enterNum",CR);
		/*if(GET_BIT(UART1->SR,6)==1){
		MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN0, GPIO_U8_HIGH);
		delay();
		MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN0, GPIO_U8_LOW);
		}*/
		//x = MUART_voidReceiveChar(UART1, CR);
		//if(x == '5')
		//{
			/*	LED ON 			*/
		//	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_HIGH);
//		}else if (x == 'A')
//		{
			/*	LED OFF		*/
//			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_LOW);

//		}
		MUART_voidTransmitInt(UART1, 10255, CR);
		int z=0;

		z=MUART_voidReceiveInt(UART1, CR);
		if(z==1)
		  {
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_HIGH);

		  }
		else if(z==9)
		  {
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_LOW);

		  }
	}
return 0;
}




