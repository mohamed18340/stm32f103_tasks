#ifndef UART_PRIVATE_H
#define UART_PRIVATE_H

#define UART1 ((volatile UART_t*)0x40013800)
#define UART2 ((volatile UART_t*)0x40004400)
#define UART3 ((volatile UART_t*)0x40004800)
#define UART4 ((volatile UART_t*)0x40004C00)
#define UART5 ((volatile UART_t*)0x40005000)

typedef struct
{
	u32 SR;
	u32 DR;
	u32 BRR;
	u32 CR[3];
	u32 GTPR;
}UART_t;



#endif
