
#include"../Inc/LIB/STD_TYPES.h"
#include"../Inc/LIB/BIT_MATH.h"

#include"../Inc/MCAL/RCC/RCC_interface.h"
#include"../Inc/MCAL/SYSTICK/STK_interface.h"
#include"../Inc/MCAL/GPIO/GPIO_interface.h"
//#include"../Inc/OS/OS_interface.h"

//#include  "../Inc/MCAL/out.h"
//#include "../Inc/HAL/Push_Button/PB_Interface.h"
#include"../Inc/MCAL/UART/UART_interface.h"
#include "../Inc/MCAL/UART/UART_private.h"
//#include"../Inc/MCAL/SPI/SPI_interface.h"
#include "../Inc/MCAL/STP/STP_interface.h"
#include "../Inc/HAL/LCD/LCD_interface.h"

#include <stddef.h>
#include "../Inc/APP/Smart_Garage/SG_interface.h"

int main(void)
{
  MRCC_voidInit();
  	MRCC_voidPerClock_State(APB2 , IOPA_PERIPHERAL, PClock_enable); //uart , leds , dc_motor
  	MRCC_voidPerClock_State(APB2 , IOPB_PERIPHERAL, PClock_enable);
  	MRCC_voidPerClock_State(APB2 , USART1_PERIPHERAL, PClock_enable);
  	MRCC_voidPerClock_State(APB1 , USART2_PERIPHERAL, PClock_enable);
	sys_init();
  	lcd_init();
  	lcd_out("HELLO");


  uart_config *CR;
  CR = NULL;
  			CR->M=eight_bits;
  			CR->PCE=ParityDisable;
  			CR->PE=Interrupt_disable;
  			CR->PS=EvenParity;
  			CR->RXNE=Interrupt_disable;
  			CR->TCIE=Interrupt_enable;
  			CR->TXEIE=Interrupt_disable;
  			CR->UE=UART_enable;
  	MUART_voidInit(UART1, CR, 0X347);
  	MUART_voidInit(UART2, CR, 0X347);
  	//MUART_voidTransmitChar(UART1, 'M', CR);
	//MUART_voidTransmitStr(UART1, "hello...",CR);
	//MUART_voidTransmitStr(UART2, "BYE EXIT...",CR);
	//lcd_out("HELLO AGAIN");
	u8 local_enter ;
	u8 local_exit;
//============================================================================
	while(1)
	{
	    //================================
	    //================================
		local_enter  = MGPIO_u8GetPinValue(GPIO_U8_PORTB, GPIO_U8_PIN0);
		if (local_enter ==1)//enter
		  {
			MUART_voidTransmitStr(UART1, "Entrance.. enter the type..",CR);

			//local_read = MUART_u8ReceiveChar(UART1, CR);
			VEH_entry(UART1, CR);
			//LCD WELCOME AND THE DIRECTION
		   }
	   //==================================
	   //==================================
		local_exit  = MGPIO_u8GetPinValue(GPIO_U8_PORTB, GPIO_U8_PIN1);

		if(local_exit ==1)
		 {
		    MUART_voidTransmitStr(UART2, "Exit...",CR);

		    VEH_exit(UART2, CR);

		 }
		/*while(local_read==0)
		{
			VEH_entry();
			//LCD WELCOME AND THE DIRECTION
			Lcd_display();

		}
		VEH_exit();
		//dc close
		motor_exit();*/
	}
}



//	// HSI  RCC INIT //
//	MRCC_voidInit();
//	//RCC UART1 //
//	MRCC_voidPerClock_State(APB2 , USART1_PERIPHERAL, PClock_enable);
//	//RCC PORT A //
//	MRCC_voidPerClock_State(APB2 , IOPB_PERIPHERAL, PClock_enable);
//	MRCC_voidPerClock_State(APB2 , IOPA_PERIPHERAL, PClock_enable);
//
//
//	//LED INIT //
//	HLed_voidInit( LED_1 ,LED_OFF);
//
//	// TX ==> A9 OUTPUT PP ALTERNATE FUNCTION //
//	MGPIO_voidSetPinDirection(GPIOA, PIN9, OUTPUT_SPEED_2MHZ_AFPP);
//	//RX ==> A10 INPUT Floating //
//	MGPIO_voidSetPinDirection(GPIOA, PIN10, INPUT_FLOATING);

	//SPI_xInit(SPI1, SPI)
	//UART INIT  //
//	MUART_voidInit(UART_1);
//	// u8 x=0;
//	//MUART1_voidTransmitint(255);
////	 MUART_voidTransmitStr(UART_1,"22");
////	 MUART_u8Reciever(UART_1);
////	 MUART_voidTransmitint( UART_1,200);
////     MUART_voidTransmitChar(UART_1, 'A');
//
//
//
////	prev_state = HLed_voidGetState(LED_1);
////	current_state = prev_state;
//	MGPIO_voidSetPinDirection(GPIOB, PIN0, OUTPUT_SPEED_10MHZ_PP);
//	while(1)
//	{
//		MGPIO_voidSetPinValue(GPIOB, PIN0, GPIO_HIGH);
////		HLed_voidTogglee(LED_1);
////		Delay();
//           if(MUART_u8Reciever(UART_1)=='A')
//           {
//        	   MGPIO_voidSetPinValue(GPIOB, PIN0, GPIO_LOW);
//        	   //HLed_voidTogglee(LED_1);
//           }
//           else
//           {
//        	   MGPIO_voidSetPinValue(GPIOB, PIN0, GPIO_HIGH);
//
//
//           }
//}
//}
