#include	"../Inc/LIB/BIT_MATH.h"
#include	"../Inc/LIB/STD_TYPES.h"
#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include	"../Inc/MCAL/UART/UART_interface.h"
#include	"../Inc/MCAL/UART/UART_private.h"
#include "../Inc/MCAL/RCC/RCC_interface.h"
#include <string.h>
#include <strings.h>

void	MUART_voidInit(UART_t* UARTn,uart_config* UART_CR,u32 BaudRate)
{
	/*	Baudrate 	9600					*/
	UARTn->BRR= BaudRate ;
	/*	UART EN , TX EN , RX EN 			*/
	UARTn->CR[0]=0x00000000;
	UARTn->CR[1]=0x00000000;
	UARTn->CR[2]=0x00000000;
	UARTn->CR[0] |=(UART_CR->UE)<<13;
	UARTn->CR[0] |=(UART_CR->M)<<12;
	UARTn->CR[0] |=(UART_CR->PCE)<<10;
	UARTn->CR[0] |=(UART_CR->PS)<<9;
	UARTn->CR[0] |=(UART_CR->TXEIE)<<7;
	UARTn->CR[0] |=(UART_CR->TCIE)<<6;
	UARTn->CR[0] |=(UART_CR->RXNE)<<5;
	
}
void	MUART_voidTransmitChar(UART_t* UARTn,u8 Data,uart_config* UART_CR)
{
	UARTn->DR=Data;
	//wait until the data enter the shift register
	while(GET_BIT(UARTn->SR,7)==0){};
	//enable the transmission
	UARTn->CR[0] |=(UART_CR->TE)<<3;
	//wait until the transmission complete
	while(GET_BIT(UARTn->SR,7)==0){};

}

void	MUART_voidTransmitStr(UART_t* UARTn,u8 arr[],uart_config* UART_CR)
{
	u8 i = 0;
	UARTn->CR[0] |=transmitter_enable<<3;

	while(arr[i] != '\0')
	{
		UARTn->DR = arr[i];
		while(GET_BIT(UARTn->SR,7)==0){};
		while((GET_BIT(UARTn->SR , 6))== 0);
		i++;
	}
}

u8	MUART_u8ReceiveChar(UART_t* UARTn,uart_config* UART_CR)
{
	UARTn->CR[0] |=reciever_enable<<2;

	u8 Local_u8Data = 0;
		while((GET_BIT(UARTn -> SR ,5))== 0);
		Local_u8Data = UARTn -> DR;
	return Local_u8Data;
}
int MUART_u8ReceiveStr(UART_t * UARTn,uart_config *UART_CR,u8 * s)
{
  u8 x =0; //NULL
  int i=0;
  while(x != 13){ //13==>ENTER
      x= MUART_u8ReceiveChar(UARTn,UART_CR);
      if(x == 13){return 0;}
      s[i] = x;
      i++;
  }
  return 0;
}
