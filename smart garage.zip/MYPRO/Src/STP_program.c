#include "../Inc/LIB/STD_TYPES.h"
#include "../Inc/LIB/BIT_MATH.h"

#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/systick/STK_interface.h"

//#include	"DIO_interface.h
//#include	"STK_interface.h

#include	"../Inc/MCAL/STP/STP_interface.h"
//#include	"../Inc/MCAL/STP/STP_private.h"
#include	"../Inc/MCAL/STP/STP_config.h"




void	HSTP_voidSendSynch(u8 Copy_u8Data)
{
	signed char Local_u8Count;
	u8 Local_u8Bit;
	for(Local_u8Count =  7 ; Local_u8Count >= 0; Local_u8Count--)
	{
		/*	Send bit by bit Starting from msb 		*/
		Local_u8Bit = GET_BIT(Copy_u8Data,Local_u8Count);
		
		/*	Send bit on the serial data pin 		*/
		MGPIO_voidSetPinValue(HSTP_SERIAL_DATA, Local_u8Bit);
		
		/*	Send clock by clock on shift register 	*/
		MGPIO_voidSetPinValue(HSTP_SHIFT_CLOCK, GPIO_U8_HIGH);
		MSTK_voidSetBusyWait_us(1);
		MGPIO_voidSetPinValue(HSTP_SHIFT_CLOCK, GPIO_U8_LOW);
		MSTK_voidSetBusyWait_us(1);
	}
	/*	Send clock by clock on STORAGE register 	*/
	MGPIO_voidSetPinValue(HSTP_STORAGE_CLOCK, GPIO_U8_HIGH);
	MSTK_voidSetBusyWait_us(1);
	MGPIO_voidSetPinValue(HSTP_STORAGE_CLOCK, GPIO_U8_LOW);
	MSTK_voidSetBusyWait_us(1);
}
