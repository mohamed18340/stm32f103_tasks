#include "../Inc/LIB/BIT_MATH.h"
#include "../Inc/LIB/STD_TYPES.h"
#include "../Inc/HAL/LCD/lcd_interface.h"
#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/GPIO/GPIO_private.h"

#include <string.h>
void en_pulse()
{
	int i=0;
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, E_PIN,GPIO_U8_HIGH);
	for (i=0;i<3000;i++);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, E_PIN,GPIO_U8_LOW);
	i=0;
	for (i=0;i<3000;i++);

}
void delay()
{
	int x=0;
	for(x=0;x<1000;x++);
}

void lcd_init(void)
{
	//MGPIO_voidSetPinDirection(GPIO_U8_PORTB, Copy_u8PinID, Copy_u8Direction)(GPIO_U8_PORTA, GPIO_U8_OUTPUT_PP_10MHZ);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, RS_PIN, GPIO_U8_OUTPUT_PP_10MHZ);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, RW_PIN, GPIO_U8_OUTPUT_PP_10MHZ);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, E_PIN, GPIO_U8_OUTPUT_PP_10MHZ);

	lcd_send_cmd(LCD_8BIT_DATA);
	delay();
	lcd_send_cmd(SHIFT_CURSOR_RIGHT);
	delay();
	lcd_send_cmd(LCD_DISPLAY_ON);
	delay();
	lcd_send_cmd(LCD_CLEAR);
	delay();

	//lcd_send_cmd(LCD_ENTRY_MODE);
	//delay();
}
void lcd_send_cmd(u8 cmd)
{
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, RS_PIN,GPIO_U8_LOW);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, RW_PIN,GPIO_U8_LOW);
	HSTP_voidSendSynch(cmd);
	en_pulse();
}
void lcd_out(u8* ptr_string){
	u8 index =0;
	/*while(ptr_string[index] != '0'){*/
	for(index=0;index<strlen(ptr_string);index++){
		lcd_out_char(ptr_string[index]);
		//index++;
		delay();
	}
}
void lcd_out_char(u8 out_char)
{
	//MGPIO_set_port_direction(GPIO_U8_PORTA, GPIO_U8_OUTPUT_PP_10MHZ);
	//MGPIO_set_port_direction(GPIO_U8_PORTA, GPIO_U8_OUTPUT_PP_10MHZ);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, RS_PIN,GPIO_U8_HIGH);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, RW_PIN,GPIO_U8_LOW);
	HSTP_voidSendSynch(out_char);
	en_pulse();
	delay();
}
void lcd_clear_all(void)
{
	lcd_send_cmd(LCD_CLEAR);
	delay();
}


