

#include"../Inc/LIB/STD_TYPES.h"
#include"../Inc/LIB/BIT_MATH.h"

#include"../Inc/MCAL/RCC/RCC_interface.h"
#include"../Inc/MCAL/systick/STK_interface.h"
#include"../Inc/MCAL/GPIO/GPIO_interface.h"


//#include  "../Inc/MCAL/out.h"
//#include "../Inc/HAL/Push_Button/PB_Interface.h"
#include"../Inc/MCAL/UART/UART_interface.h"
//#include"../Inc/MCAL/SPI/SPI_interface.h"
#include "../Inc/MCAL/STP/STP_interface.h"
#include "../Inc/HAL/LCD/LCD_interface.h"
#include <string.h>
#include "../Inc/APP/Smart_Garage/SG_interface.h"
//#include <stddef.h>
#include <stdio.h>
const u8 size_veh =3;
static u8 L_u8counter_suv =0;
static u8 L_u8counter_sedan =0;
static u8 L_u8counter_motorcycle =0;
/*void Delay(void)
{
  int i=0;
  for (i=0;i<10000;i++);
}
void DelayMotor(void)
{
  int j=0;
  for (j=0;j<600000;j++);
}
void delay2(void)
{
  int k =0;
  for(k=0;k<50000;k++);
}*/
void sys_init()
{

	MGPIO_voidSetPinDirection(GPIO_U8_PORTB, GPIO_U8_PIN2, GPIO_U8_OUTPUT_PP_10MHZ); //dc motor entry
	MGPIO_voidSetPinDirection(GPIO_U8_PORTB, GPIO_U8_PIN3, GPIO_U8_OUTPUT_PP_10MHZ); //dc motor entry
	MGPIO_voidSetPinDirection(GPIO_U8_PORTB, GPIO_U8_PIN4, GPIO_U8_OUTPUT_PP_10MHZ); //dc motor entry

	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN6, GPIO_U8_OUTPUT_PP_10MHZ); //dc motor entry
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN7, GPIO_U8_OUTPUT_PP_10MHZ); //dc motor entry

	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN12, GPIO_U8_OUTPUT_PP_10MHZ); //dc motor exit
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN13, GPIO_U8_OUTPUT_PP_10MHZ); //dc motor exit

	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN14, GPIO_U8_OUTPUT_PP_10MHZ);  //led green
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_OUTPUT_PP_10MHZ);  //led red

	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN9, GPIO_U8_OUTPUT_AF_PP_10MHZ); // TX ==> A9 OUTPUT PP ALTERNATE FUNCTION ////uart1
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN10, GPIO_U8_INPUT_FLOATING);//RX ==> A10 INPUT Floating //
	//uart3
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN2, GPIO_U8_OUTPUT_AF_PP_10MHZ); // TX ==> A OUTPUT PP ALTERNATE FUNCTION //
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN3, GPIO_U8_INPUT_FLOATING);//RX ==> A INPUT Floating //
	MGPIO_voidSetPinDirection(GPIO_U8_PORTB, GPIO_U8_PIN0,GPIO_U8_INPUT_PULL_DOWN);
	MGPIO_voidSetPinValue(GPIO_U8_PORTB, GPIO_U8_PIN0, 0);

	MGPIO_voidSetPinDirection(GPIO_U8_PORTB, GPIO_U8_PIN1,GPIO_U8_INPUT_PULL_DOWN);
	MGPIO_voidSetPinValue(GPIO_U8_PORTB, GPIO_U8_PIN1, 0);

	MSTK_voidInit();


}

void VEH_entry(UART_t * UARTn,uart_config *UART_CR)
{
   u8  L_AV_type[10]={}  ;
  //u8 * s;
	lcd_clear_all();
	lcd_out("ENTER TYPE");
	lcd_send_cmd(LINE2_BEGINNING);
	lcd_out("SUV,SEDAN,MOTOR");
	MUART_u8ReceiveStr(UARTn,UART_CR,L_AV_type);
	//strcpy(L_AV_type,s);
	//L_AV_type=MUART_u8ReceiveStr(UARTn,UART_CR); //MUART_u8Reciever(UART_1 , L_AV_type)
	//free(s);
	lcd_clear_all();
	lcd_out(L_AV_type);
	MSTK_voidSetBusyWait_s(1);
	check_availabile(L_AV_type);
	            //uart1
	//L_AV_type = NULL;
	//Lcd_display(L_AV_type);
}

void check_availabile(u8* copy_avilable)
{
	lcd_clear_all();
	lcd_out("Checking..");
	MSTK_voidSetBusyWait_s(1);
	lcd_clear_all();

	//copy_avilable=copy_avilable-49; // or strcmp(copy_avilable,"suv") or switch case "suv"
//=============================================================================
	if(strcmp(copy_avilable,"SUV")==0)
	{

		if(L_u8counter_suv < size_veh)
		{
			lcd_out("available..");
			lcd_send_cmd(LINE2_BEGINNING);
			lcd_out("door opening..");
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN14, GPIO_U8_HIGH); //led green
			//DC_MOTOR OPEN
			motor_entry();
			L_u8counter_suv++;
			//DC_MOTOR CLOSE
			//motor_close_entry();
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN14, GPIO_U8_LOW);
			// LCD display inside the garage after the car enter
			lcd_clear_all();
			lcd_out("WELCOME..");
			MSTK_voidSetBusyWait_ms(500);
			lcd_clear_all();
			lcd_out("TURN RIGHT");
			MSTK_voidSetBusyWait_s(1);
			lcd_clear_all();

		}
		else
		{
		    lcd_out("not available..");
		    MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_HIGH); //led red
		    MSTK_voidSetBusyWait_s(2);
		    MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_LOW);
		    lcd_clear_all();


		}
	}
//=============================================================================
	else if(strcmp(copy_avilable,"SEDAN")==0)
	  {
		if(L_u8counter_sedan < size_veh)
		{
		    lcd_out("available..");
		    lcd_send_cmd(LINE2_BEGINNING);
		    lcd_out("door opening..");
		    MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN14, GPIO_U8_HIGH); //led green
		    //DC_MOTOR OPEN
		    motor_entry();
		    L_u8counter_sedan++;
		    //DC_MOTOR CLOSE
		    //motor_close_entry();
		    MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN14, GPIO_U8_LOW);
		    lcd_clear_all();
		    lcd_out("WELCOME..");
		    MSTK_voidSetBusyWait_ms(500);
		    lcd_clear_all();
		    lcd_out("GO STRAIGHT");
		    MSTK_voidSetBusyWait_s(1);
		    lcd_clear_all();

		}
		else
		{
		    lcd_out("not available..");
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_HIGH); //led red
			MSTK_voidSetBusyWait_s(2);
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_LOW);
			lcd_clear_all();

		}

	  }
//===========================================================================
	else if(strcmp(copy_avilable,"MOTORCYCLE")==0)
	  {
		if(L_u8counter_motorcycle < size_veh)
		{
		    lcd_out("available");
		    lcd_send_cmd(LINE2_BEGINNING);
		    lcd_out("door opening..");
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN14, GPIO_U8_HIGH); //led green
			//DC_MOTOR OPEN
			motor_entry();
			L_u8counter_motorcycle++;
			//DC_MOTOR CLOSE
			//motor_close_entry();
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN14, GPIO_U8_LOW);
			lcd_clear_all();
				  lcd_out("WELCOME..");
					MSTK_voidSetBusyWait_ms(500);
				    lcd_clear_all();
				    lcd_out("TURN LEFT");
					MSTK_voidSetBusyWait_s(1);
				    lcd_clear_all();


		}
		else
		{
		    lcd_out("not available");
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_HIGH); //led red
			MSTK_voidSetBusyWait_s(2);
			MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN15, GPIO_U8_LOW);
			lcd_clear_all();


		}
	  }
	else
		  {
	    lcd_out("INVALID TYPE");
		MSTK_voidSetBusyWait_ms(500);
		    lcd_clear_all();

		  }
}


void motor_entry(void)
{
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN6, GPIO_U8_HIGH);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN7, GPIO_U8_LOW);
	MSTK_voidSetBusyWait_s(6);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN6, GPIO_U8_LOW);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN7, GPIO_U8_HIGH);
	MSTK_voidSetBusyWait_s(4);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN6, GPIO_U8_LOW);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN7, GPIO_U8_LOW);
	//DelayMotor();
	//MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN6, GPIO_U8_LOW);
	//MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN7, GPIO_U8_LOW);

}

/*void motor_close_entry(void)
{


}*/

void motor_exit(void)
{
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN12, GPIO_U8_HIGH);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN13, GPIO_U8_LOW);
	MSTK_voidSetBusyWait_s(6);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN12, GPIO_U8_LOW);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN13, GPIO_U8_HIGH);
	MSTK_voidSetBusyWait_s(4);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN12, GPIO_U8_LOW);
	MGPIO_voidSetPinValue(GPIO_U8_PORTA, GPIO_U8_PIN13, GPIO_U8_LOW);
 }

/*void Lcd_display(u8* type)
{


	if(strcmp(type,"SUV")==0)
	  {

	  }
	else if(strcmp(type,"SEDAN")==0)
	  {



	  }
	else if(strcmp(type,"MOTORCYCLE")==0)
	  {

	  }
}*/

void VEH_exit(UART_t * UARTn,uart_config *UART_CR)
{
    u8 L_AV_type_exit [10] = {};        //uart3
    MUART_voidTransmitStr(UART2, "enter type...", UART_CR);
	MUART_u8ReceiveStr(UARTn, UART_CR,L_AV_type_exit); // UART3

	lcd_clear_all();
	lcd_out(L_AV_type_exit);
	check_exit_type(L_AV_type_exit);

}

void check_exit_type(u8 *copy_exit)
{
	if(strcmp(copy_exit,"SUV")==0)
	{
	    lcd_out("...bye!");
	    lcd_send_cmd(LINE2_BEGINNING);
	    lcd_out("door opening..");
	    motor_exit();
	    L_u8counter_suv--;
	    lcd_clear_all();
	}
	else if(strcmp(copy_exit,"SEDAN")==0)
	{
	    lcd_out("...bye!");
	    lcd_send_cmd(LINE2_BEGINNING);
	    lcd_out("door opening..");
	    motor_exit();
	    L_u8counter_sedan--;
	    lcd_clear_all();
	}
	else if(strcmp(copy_exit,"MOTORCYCLE")==0)
	{
	    lcd_out("...bye!");
	    lcd_send_cmd(LINE2_BEGINNING);
	    lcd_out("door opening..");
	    motor_exit();
	    L_u8counter_motorcycle--;
	    lcd_clear_all();
	}
	else
	  {
	    lcd_clear_all();
	    lcd_out("INVALID TYPE");
	    MSTK_voidSetBusyWait_ms(500);
	    lcd_clear_all();
	  }


}

















