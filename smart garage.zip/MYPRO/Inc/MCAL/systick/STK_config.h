#ifndef		STK_CONFIG_H
#define		STK_CONFIG_H


#define MSTK_CLK_SRC		MSTK_SRC_AHB_8

#endif
