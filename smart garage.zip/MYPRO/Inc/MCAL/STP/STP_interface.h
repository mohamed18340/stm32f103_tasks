#ifndef STP_INTERFACE_H
#define STP_INTERFACE_H
#include "../Inc/LIB/STD_TYPES.h"
void	HSTP_voidSendSynch(u8 Copy_u8Data);
#endif
