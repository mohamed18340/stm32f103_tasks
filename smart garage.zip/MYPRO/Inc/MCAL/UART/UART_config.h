#ifndef UART_CONFIG_H
#define UART_CONFIG_H
//#if شوية
//select the baud rate
/*
for 8Mhz
9600   ->UART div = 52.08
F=1
M=34
115200 -> UART div = 4.34
F= 0x5
M=0x4
*/
#endif
/*
#ifndef		UART_CONFIG_H
#define		UART_CONFIG_H

/*

for8MHz
9600	->	UARTDiv =52.08
F=0x1
M=0x34

115200 ->	UARTDiv =4.34
F=0x5
M=0x4
*/
