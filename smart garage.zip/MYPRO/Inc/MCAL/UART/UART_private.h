#ifndef UART_PRIVATE_H
#define UART_PRIVATE_H
#define UART1 ((volatile UART_t*)0x40013800)
#define UART2 ((volatile UART_t*)0x40004400)
#define UART3 ((volatile UART_t*)0x40004800)
#define UART4 ((volatile UART_t*)0x40004C00)
#define UART5 ((volatile UART_t*)0x40005000)

typedef struct
{
	u32 SR;
	u32 DR;
	u32 BRR;
	u32 CR[3];
	u32 GTPR;
}UART_t;

/*typedef enum
{
	idle_line,AddressMask
}wakeup_method;*/

/*typedef enum
{
	PE_inhibited,PE_enable
}ParityErrorInterrupt;
typedef enum
{
	TXE_disable,TXE_enable
}TXE_interrupt;
typedef enum
{
	TC_disable,TC_enable
}TranmitCompleteInterrupt;
typedef enum
{
	RXNE_disable,RXNE_enable
}RXNE_interrupt;
typedef enum
{

}IDLE_interr;*/

/*typedef enum
{
	reciever_active,reciever_mute
}reciever_wakeup;*/
/*typedef enum
{
	NoBreak,SendBreak
}break_char;
typedef enum
{
	LIN_disable,LIN_enable
}LIN_mode;
typedef enum
{
	stop_oneBit,stop_halfBit,stop_twoBit,stop_one_and_half
}stop_bits;
typedef enum
{
	clock_disable,clock_enable
}clock_pin;
typedef enum
{
	lowValue,highValue
}clockPolarity;
typedef enum
{
	first_transition,second_transition
}clockPhase;*/

#endif
