#ifndef LCD_INTERFACE_H
#define LCD_INTERFACE_H
void lcd_init(void);
void lcd_out(u8 *ptr_string);
//void lcd_out_cp(char out_data[32]);
void lcd_out_char(u8 out_char);
//void lcd_out_char_cp(char out_char);
void lcd_clear_all(void);
void lcd_send_cmd(u8 cmd);


#define LCD_CLEAR             0x01 /* replace all characters with ASCII 'space'     */
#define LCD_RETURN_HOME       0x02 /* return cursor to first position on first line */
#define SHIFT_CURSOR_RIGHT    0x06 /* shift cursor from left to right on read/write */
#define LCD_DISPLAY_OFF       0x08 /* turn display off                              */
#define LCD_DISPLAY_ON        0x0F /* display on, cursor off, don't blink character */
#define LCD_RESET       	  0x30 /* reset the LCD                                 */
#define LCD_8BIT_DATA  		  0x38 /* 8-bit data, 2-line display, 5 x 7 font        */
#define LINE1_BEGINNING       0x80 /* set cursor position                           */
#define LINE2_BEGINNING       (0x80+0x40)
#define RS_PIN 5
#define RW_PIN 4
#define E_PIN 8

#endif
