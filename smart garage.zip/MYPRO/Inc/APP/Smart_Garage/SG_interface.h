/*
 * SG_interface.h
 *
 *  Created on: Sep 13, 2022
 *      Author: Swelam
 */

#ifndef APP_SMART_GARAGE_SG_INTERFACE_H_
#define APP_SMART_GARAGE_SG_INTERFACE_H_

void sys_init();
void VEH_entry(UART_t * UARTn,uart_config *UART_CR);
void check_availabile(u8* copy_avilable);
void motor_entry(void);
//void motor_close_entry(void);
void motor_exit(void);
//void Lcd_display(u8 * L_AV_type);
void VEH_exit(UART_t * UARTn,uart_config *UART_CR);
void check_exit_type(u8 *copy_exit);


#endif /* APP_SMART_GARAGE_SG_INTERFACE_H_ */
