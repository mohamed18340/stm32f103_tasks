/*
 * SG_private.h
 *
 *  Created on: Sep 13, 2022
 *      Author: Swelam
 */

#ifndef APP_SMART_GARAGE_SG_PRIVATE_H_
#define APP_SMART_GARAGE_SG_PRIVATE_H_



#endif /* APP_SMART_GARAGE_SG_PRIVATE_H_ */
