#include "../Inc/LIB/BIT_MATH.h"
#include "../Inc/LIB/STD_TYPES.h"
#include "../Inc/MCAL/GPIO/GPIO_interface.h"
#include "../Inc/MCAL/RCC/RCC_interface.h"
#include "../Inc/MCAL/STP/STP_interface.h"
#include "../Inc/MCAL/systick/STK_interface.h"
#include "../Inc/HAL/LCD/lcd_interface.h"
#define zero 0x40
#define one 0x79
#define two 0x24
#define three 0x30
#define four 0x0A
#define five 0x12
int main(void)
{
	MRCC_voidInit();
	MRCC_voidPerClock_State(APB2, IOPA_PERIPHERAL, PClock_enable);
	MRCC_voidPerClock_State(APB2, IOPB_PERIPHERAL, PClock_enable);

	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN0, GPIO_U8_OUTPUT_PP_10MHZ);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN1, GPIO_U8_OUTPUT_PP_10MHZ);
	MGPIO_voidSetPinDirection(GPIO_U8_PORTA, GPIO_U8_PIN2, GPIO_U8_OUTPUT_PP_10MHZ);
	MSTK_voidInit();
	HSTP_voidSendSynch(five);
	lcd_init();
	lcd_out_char('A');
    /* Loop forever */

}
